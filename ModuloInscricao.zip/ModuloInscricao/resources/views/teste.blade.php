<h1 style="color: blue">Inscreva-se</h1>

<form action="{{route('inscricao.store')}}" method="post" enctype="multipart/form-data">
        @csrf
      
       <div class="row"> 

        <div class="form-group col-md-6 required ">
            <label >Nome Completo<strong style="color: red">*</strong></label>
            <input type="text" name="name" id="name" class="form-control @error('name') is-invalid @enderror" value="{{old('name')}}">

            @error('rua')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>
                                    
        <div class="form-group col-md-2">
            <label>Data de nascimento <strong style="color: red">*</strong></label>
            <input type="text" name="nascimento" id="nascimento" class="form-control @error('numero') is-invalid @enderror" value="{{old('numero')}}" >

            @error('numero')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>

        <div class="form-group col-md-3">
            <label>Sexo<strong style="color: red">*</strong></label>
            <input type="text" name="Sexo" id="sexo" class="form-control @error('cidade') is-invalid @enderror" value="{{old('cidade')}}" placeholder='@lang('Informe o município')'>

            @error('cidade')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>

        <div class="form-group col-md-1">
            <label>CPF<strong style="color: red">*</strong></label>
            <input type="text" name="cpf" id="cpf" class="form-control @error('estado') is-invalid @enderror" value="{{old('estado')}}" placeholder='@lang('Ex:SC')'>

            @error('estado')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>

       <div class="form-group col-md-1">
            <label>Curso<strong style="color: red">*</strong></label>
            <input type="text" name="curso" id="curso" class="form-control @error('curso') is-invalid @enderror" value="{{old('curso')}}" placeholder='@lang('Ex:SC')'>

            @error('estado')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>

    </div>


        <div>
            <button type="submit" class="btn btn-lg" style="background-color: #228B22; 
            color: #ffffff">Cadastro</button>
        </div>
    </form>
