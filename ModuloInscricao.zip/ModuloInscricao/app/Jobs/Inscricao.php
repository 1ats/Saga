<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use App\Models\Registrations;


class Inscricao implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $data;

    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
       
     

       if (!empty($this->data['status_payment'])) {
         
        $status_payment = $this->data['status_payment'];
        $id = $this->data['inscricao_id'];

       } else {

       $status_payment = "a";
      }

         if (!empty($this->data['status_invoice'])) {
         
         $status_invoice = $this->data['status_invoice'];
         $idInvoice = $this->data['inscri_id'];

       } else {

        $status_invoice = "a";
       }
       
   
       if ($status_payment  == "recusado") {
          
        $inscricao = Registrations::findOrFail($id); 

        $inscricao->status_registration = "cancelado";
        $inscricao->status_payment = $this->data['status_payment']; //recusado
        $inscricao->cpf =  $this->data['cpf'];
        
        $inscricao->update();

        
         $inscricao = Registrations::where('id',$id)->get(); 
        Inscricao::dispatch($inscricao->toArray()); 

       } elseif ($status_payment  == "aceite") {
          
        $inscricao = Registrations::findOrFail($id); 

        $inscricao->status_registration = "pendente";
        $inscricao->status_payment = $this->data['status_payment']; //aceite
        $inscricao->cpf =  $this->data['cpf'];
      

        $inscricao->update();

        $inscricao = Registrations::where('id',$id)->get(); 
         Inscricao::dispatch($inscricao->toArray()); 

       } else{
         
         echo  "nenhum evento ocorreu";
       }


      if ($status_invoice == "cpf incorreto") {
          
        $inscricao = Registrations::findOrFail($idInvoice); 

        $inscricao->status_registration = "cancelado";
        $inscricao->status_payment = "cancelado"; 
        $inscricao->status_invoice = "cpf incorreto"; 
        
        $cpfI = Registrations::where('id',$idInvoice)->get('cpf')->first(); 
        $inscricao->cpf = $cpfI->cpf;
        
        $inscricao->update();

        
        // $inscricao = Registrations::where('id',$idInvoice)->get(); 
        Inscricao::dispatch($inscricao->toArray()); 

       } elseif ($status_invoice == "cpf correto") {
          
        $inscricao = Registrations::findOrFail($idInvoice); 

        $inscricao->status_registration = "vigente";
        $inscricao->status_payment = "aceite"; 
        $inscricao->status_invoice = "cpf correto"; 
        
       $cpfI = Registrations::where('id',$idInvoice)->get('cpf')->first(); 
        $inscricao->cpf = $cpfI->cpf;
      

        $inscricao->update();

      //  $inscricao = Registrations::where('id',$idInvoice)->get(); 
         Inscricao::dispatch($inscricao->toArray()); 

       } else{
         
         return "nenhum evento ocorreu";
       }
    
    

  }

}
