<?php
// This is an example handler class

namespace App\Messaging\Handlers;

class AuthorHandler {

	public function handle($msg)
	{
		echo "Author: ".$msg->body;
	}

    public function handleError($e, $broker)
    {
        if($e instanceof InvalidInputException) {
            $broker->rejectMessage();
        } elseif($e instanceof WhatEverException) {
            $broker->ackMessage();
        } elseif($e instanceof WhatElseException) {
            $broker->nackMessage();
        } else {
            $msg = $broker->getMessage();
            if($msg->body) {
                //
            }
        }
    }
}