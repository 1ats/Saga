<?php

namespace App\Messaging\Handlers;

use Exception;
use PhpAmqpLib\Message\AMQPMessage;
use Vinelab\Bowler\MessageBroker;

class AnalyticsDataHandler
{
    /**
     * Handle message.
     *
     * @param AMQPMessage $msg
     *
     * @return void
     */
    public function handle(AMQPMessage $msg)
    {
        //
    }

    /**
     * Handle error
     *
     * @param Exception|Throwable $e
     * @param MessageBroker $broker
     *
     * @return void
     */
    public function handleError($e, $broker)
    {
        //
    }
}
