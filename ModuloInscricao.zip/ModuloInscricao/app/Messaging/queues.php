<?php

Registrator::queue('books', 'App\Messaging\Handlers\BookHandler', []);

Registrator::queue('reporting', 'App\Messaging\Handlers\ErrorReportingHandler', [
                                                        'exchangeName' => 'main_exchange',
                                                        'exchangeType'=> 'direct',
                                                        'bindingKeys' => [
                                                            'warning',
                                                            'notification'
                                                        ],
                                                        'pasive' => false,
                                                        'durable' => true,
                                                        'autoDelete' => false,
                                                        'deadLetterQueueName' => 'dlx_queue',
                                                        'deadLetterExchangeName' => 'dlx',
                                                        'deadLetterExchangeType' => 'direct',
                                                        'deadLetterRoutingKey' => 'warning',
                                                        'messageTTL' => null
                                                    ]);
Registrator::queue('analytics_queue', 'App\Messaging\Handlers\AnalyticsDataHandler', []);
