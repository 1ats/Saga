<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Registrations;
use App\Models\Invoices;
use App\Jobs\Inscricao;

class NotaFiscalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $cpf = Registrations::where('cpf', $request->cpf)->get('cpf')->first();
        $id = Registrations::where('cpf', $request->cpf)->get('inscricao_id')->first();

       
        if (!empty($cpf->cpf)) {
            
            $cpfs = $cpf->cpf;

        } else {

            $cpfs = "1";
        }

        if ($cpfs == $request->cpf) {
            
           $invoices = new Invoices();

           $invoices->status_invoice = "cpf correto";
           $invoices->inscri_id = $request->codigo;
           $invoices->cpf = $cpf->cpf;

           $invoices->save();

           Inscricao::dispatch($invoices->toArray()); 

            $mensagem = "Nota Fiscal emitido com sucesso";
            return view('invoice', compact('mensagem')); 

        } else {

           $invoices = new Invoices();

           $invoices->status_invoice = "cpf incorreto";
           $invoices->inscri_id = $request->codigo;
          // $invoices->cpf = $cpfInvoice->cpf;

           //$invoices->cpf = "";


           Inscricao::dispatch($invoices->toArray()); 

           $invoices->save();

             $mensagem = "Cpf incorreto sua inscrição/pagamento foi cancelado";
            return view('invoice', compact('mensagem')); 


        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
