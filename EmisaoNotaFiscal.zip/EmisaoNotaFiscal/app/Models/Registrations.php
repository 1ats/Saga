<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Registrations extends Model
{
    use HasFactory;

     protected $fillable = ['name', 'uuid','nascimento', 'cpf', 'curso', 'status_registration', 'status_payment', 'status_invoice'];
   
    protected $quarded = [];
}
