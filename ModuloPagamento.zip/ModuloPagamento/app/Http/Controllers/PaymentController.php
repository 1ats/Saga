<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Payments;
use App\Models\Registrations;
use App\Jobs\Inscricao;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       
       
        $status = Registrations::where('cpf',$request->cpf)->get('cpf')->first();


        if ($status) {
         
          $status =  $status->cpf;
        } else {

            $status = 1;
        }


        if ($request->cpf) {
           
        if ($status == $request->cpf) {
        
         $inscricaoId = Registrations::where('cpf',$request->cpf)->get('inscricao_id')->first();
         $curso = Registrations::where('cpf',$request->cpf)->get('curso')->first();
         

           $dadosBancarios = [

           "cartao" => "6364 5053 8185 8549",
           "validade" => "04/30",
           "cw" => "400",
           "nome" => "Alberto Soki"

         ];

        return view('payment_create', compact('inscricaoId','dadosBancarios', 'curso')); 
    }
        
        } elseif ($request->status_payment){
            
          $payment = new Payments();

          $payment->status_payment = $request->status_payment;
          $payment->numero = $request->numero;
          $payment->nome = $request->nome;
          $payment->validade = $request->validade;
          $payment->cw = $request->cw;
          $payment->parcela = $request->parcela;
          $payment->inscricao_id = $request->inscricao_id;

           $cpf = Registrations::where('inscricao_id',$request->inscricao_id)->get('cpf')->first();

          $payment->cpf = $cpf->cpf;

          $payment->save();

         //  flash($request->status_payment)->success();
          // return redirect()->route('payment_create');

             $dadosBancarios = [

           "cartao" => "6364 5053 8185 8549",
           "validade" => "04/30",
           "cw" => "400",
           "nome" => "Alberto Soki"

         ];

           Inscricao::dispatch($payment->toArray()); 

          
           $inscricaoId = Registrations::where('cpf',$request->cpf)->get('inscricao_id')->first();

           return view('payment_create', compact('dadosBancarios', 'inscricaoId'));

        } else {

            // flash('Não foi possível verificar a sua inscrição')->error();
     //   return redirect()->route('payment');

        return view('payment');
        }



    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
