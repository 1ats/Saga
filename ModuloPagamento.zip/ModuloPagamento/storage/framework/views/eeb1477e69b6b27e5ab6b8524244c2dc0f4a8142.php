
<h1>Modulo de pagamento</h1>

<h3> Curso de <?php echo e($curso->curso ?? ''); ?></h3>


<form action="<?php echo e(route('payment.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

      
       <div class="row"> 

        <div class="form-group col-md-6 required ">
            <label >Número do Cartão<strong style="color: red">*</strong></label>
            <input type="text" name="numero" id="numero" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($dadosBancarios['cartao'] ?? ''); ?> ">

            <?php $__errorArgs = ['rua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

          <div class="form-group col-md-6 required ">
            <label >Nome que consta no cartão<strong style="color: red">*</strong></label>
            <input type="text" name="nome" id="nome" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($dadosBancarios['nome'] ?? ''); ?>">

            <?php $__errorArgs = ['rua'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
                                    
        <div class="form-group col-md-2">
            <label>Validade<strong style="color: red">*</strong></label>
            <input type="text" name="validade" id="validade" class="form-control <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($dadosBancarios['validade'] ?? ''); ?>" >

            <?php $__errorArgs = ['numero'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group col-md-3">
            <label>CW/Código de segurança<strong style="color: red">*</strong></label>
            <input type="text" name="cw" id="cw" class="form-control <?php $__errorArgs = ['cidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($dadosBancarios['cw'] ?? ''); ?>" placeholder='<?php echo app('translator')->get('Informe o município'); ?>'>

            <?php $__errorArgs = ['cidade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>



         <div class="form-group col-md-3">
            <label>Parcelamento</label>
            <select name="parcela" id="parcela" class="form-control">
        
                    <option value="">1 de R$ 200</option>
                    <option value="">2  de R$ 100</option>
                
            </select>
        </div>



         <div class="form-group col-md-3">
            <label>status</label>
            <select name="status_payment" id="status_payment" class="form-control">
        
                    <option value="aceite">aceite</option>
                    <option value="recusado">recusado</option>
                
            </select>
        </div>


    <input type="text" name="inscricao_id" value="<?php echo e($inscricaoId->inscricao_id ?? ''); ?>">
        

    </div>


        <div>
            <button type="submit" class="btn btn-lg" style="background-color: #228B22; 
            color: #ffffff">Publicar</button>
        </div>
    </form>
<?php /**PATH /opt/lampp/htdocs/ModuloPagamento/resources/views/payment_create.blade.php ENDPATH**/ ?>