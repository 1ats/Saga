
<h1>Modulo de pagamento</h1>


<form action="{{route('payment.store')}}" method="post" enctype="multipart/form-data">
        @csrf
      
       <div class="row"> 
        <div class="form-group col-md-6 required ">
            <label >Informe o seu CPF<strong style="color: red">*</strong></label>
            <input type="text" name="cpf" id="cpf" class="form-control @error('cpf') is-invalid @enderror" value="">

            @error('rua')
            <div class="invalid-feedback">
                {{$message}}
            </div>
            @enderror
        </div>                             
    </div>


        <div>
            <button type="submit" class="btn btn-lg" style="background-color: #228B22; 
            color: #ffffff">Pagar</button>
        </div>
    </form>
